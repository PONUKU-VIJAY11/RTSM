library(shiny)
library(viridis)

df <- read_csv('C:/Users/ponuku vijay/Downloads/t_data.csv')
df$Domestic[is.na(data$Value)] <- 0
df$Foreign[is.na(data$Value)] <- 0
df$AG_Domestic[is.na(data$Value)] <- 0
df$AG_Foreign[is.na(data$Value)] <- 0


ui <- fluidPage(
  titlePanel("Bar Plots"),
  sidebarLayout(
    sidebarPanel(
      selectInput("breaks", "Choose method for breaks:",
                  choices = c("Domestic", "Foreign", "Domestic Growth", "Foreign Growth"),
                  selected = "Domestic")
    ),
    mainPanel(
      plotOutput("barplot")
    )
  )
)
cc1 <-viridis::viridis(n=20)
cc2 <-viridis::turbo(n=20)

server <- function(input, output) {
  output$barplot <- renderPlot({
    if (input$breaks == "Domestic") {
      barplot(df$Domestic, names.arg = df$Year, main = "Travellers domestic", xlab = "Year", ylab = "Value", col = cc1)
    } else if (input$breaks == "Foreign") {
      barplot(df$Foreign, names.arg = df$Year, main = "Travellers Foreign", xlab = "Year", ylab = "Value",col = cc2)
    } else if (input$breaks == "Domestic Growth") {
      plot(df$Year, df$AG_Domestic, type = "l", col = "red", main = "Domestic Tourism growth", xlab = "Year", ylab = "Value")
    } else if (input$breaks == "Foreign Growth") {
      plot(df$Year, df$AG_Foreign, type = "l", col = "brown", main = "Foreign Tourism Growth", xlab = "Year", ylab = "Value")
    }
  })
}

shinyApp(ui, server)
